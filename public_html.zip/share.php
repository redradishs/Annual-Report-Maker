<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

$servername = "localhost";
$username = "u140630687_arco"; // Change this to your MySQL username
$password = "ArcoDB_GCCCS2024"; // Change this to your MySQL password
$dbname = "u140630687_arco_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    echo json_encode(['error' => 'Connection failed: ' . $conn->connect_error]);
    exit();
}

if (isset($_GET['link_token'])) {
    $link_token = $_GET['link_token'];
    // Fetch shared content
    $sql = "SELECT post_id, can_edit, view_limit, destroy_after_view, views, created_at FROM shareable_links WHERE link_token = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $link_token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if ($row['views'] >= $row['view_limit']) {
            echo json_encode(['error' => 'The document has been destroyed']);
            exit();
        }

        $post_id = $row['post_id'];
        $can_edit = $row['can_edit'];
        $view_limit = $row['view_limit'];
        $views = $row['views'];
        $created_at = $row['created_at'];
        $destroy_after_view = $row['destroy_after_view'];

        // Fetch content
        $sql = "SELECT content FROM richtext WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $post_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $content_row = $result->fetch_assoc();
            $content = $content_row['content'];

            // Update views
            $sql = "UPDATE shareable_links SET views = views + 1 WHERE link_token = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('s', $link_token);
            $stmt->execute();

            if ($destroy_after_view && $row['views'] + 1 >= $row['view_limit']) {
                // Delete the link if it should be destroyed after view
                $sql = "DELETE FROM shareable_links WHERE link_token = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param('s', $link_token);
                $stmt->execute();
            }

            echo json_encode([
                'content' => $content,
                'can_edit' => $can_edit,
                'view_limit' => $view_limit,
                'views' => $views,
                'created_at' => $created_at,
                'destroy_after_view' => $destroy_after_view
            ]);
        } else {
            echo json_encode(['error' => 'Content not found']);
        }
    } else {
        echo json_encode(['error' => 'Invalid link']);
    }

    $stmt->close();
} else {
    echo json_encode(['error' => 'No link token provided']);
}

$conn->close();
?>
