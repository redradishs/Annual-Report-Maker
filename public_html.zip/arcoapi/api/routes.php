<?php

// // Allow from any origin
// if (isset($_SERVER['HTTP_ORIGIN'])) {
//     header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
//     header('Access-Control-Allow-Credentials: true');
//     header('Access-Control-Max-Age: 86400'); // cache for 1 day
// }

// // Access-Control headers are received during OPTIONS requests
// if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

//     if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
//         header("Access-Control-Allow-Methods: GET, POST, DELETE, PUT, OPTIONS");  

//     if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
//         header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

//     exit(0);
// }

// header("Content-Type: application/json");


header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, DELETE, PUT, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

// Handle OPTIONS request for preflight check
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD'])) {
        header("Access-Control-Allow-Methods: GET, POST, DELETE, PUT, OPTIONS");
    }
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS'])) {
        header("Access-Control-Allow-Headers: Content-Type, Authorization");
    }
    exit(0);
}




require_once("config/database.php");
require_once("modules/post.php");
require_once("modules/get.php");
require_once("modules/put.php");
require_once("modules/delete.php");




$con = new Connection();
$pdo = $con->connect();


$get = new Get($pdo);
$post = new Post($pdo);
$put = new Put($pdo);
$delete = new Delete($pdo);


if(isset($_REQUEST['request'])){

    $request = explode('/', $_REQUEST['request']);
}
else{
    http_response_code(404);
    echo json_encode(["error" => "Not Found"]);
    exit;
}

switch($_SERVER['REQUEST_METHOD']){
    case 'GET':
        switch($request[0]){
            case 'get_signup':
                if(count($request)>1){
                    echo json_encode($get->get_signup($request[1]));
                }
                else{
                    echo json_encode($get->get_signup());
                }
                break;

                case 'eventexpenses': 
                    if(count($request)>1){
                        echo json_encode($get->get_eventexpenses($request[1]));
                          }
                       else{
                         echo json_encode($get->get_eventexpenses($data));
                           }
                        break;
                        
                case 'eventexpensessummary': 
                    if(count($request)>1){
                        echo json_encode($get->get_eventexpensessummary($request[1]));
                          }
                       else{
                         echo json_encode($get->get_eventexpensessummary($data));
                           }
                        break;

                
            case 'flipbook':
                if(count($request)>1){
                    echo json_encode($get->get_flipbook($request[1]));
                }
                else{
                    echo json_encode($get->get_flipbook($data));
                }
                break;
                
                case 'profilepage':
                        if(count($request)>1){
                            echo json_encode($get->get_profile($request[1]));
                        }
                        else{
                            echo json_encode($get->get_profile($data));
                        }
                        break;
            
            case 'flipbook_all':
                 if(count($request)>1){
                echo json_encode($get->get_flipbookall($request[1]));
                    }
                 else{
                     echo json_encode($get->get_flipbookall());
                 }
                 break;
            //COLLAGE FINAL
            case 'collage':
                if(count($request)>1){
                    echo json_encode($get->get_collage($request[1]));
                }
                else{
                    echo json_encode($get->get_collage($data));
                }
                break;

                //COLLAGE ALL FINAL
                case 'collage_all':
                    if(count($request)>1){
                        echo json_encode($get->getCollageAll($request[1]));
                    }
                    else{
                        echo json_encode($get->getCollageAll($data));
                    }
                    break;
                
            case 'reports':
                if(count($request)>1){
                    echo json_encode($get->get_reports($request[1]));
                }else{
                    echo json_encode($get->get_reports($data));
                }
                break;

            case 'reports_all':
                 if(count($request)>1){
                    echo json_encode($get->get_reportsall($request[1]));
                 }else{
                     echo json_encode($get->get_reportsall());
                    }
                    break;
             case 'annualreport': 
                     if(count($request)>1){
                      echo json_encode($get->get_annualReport($request[1]));
                     }
                        else{
                      echo json_encode($get->get_annualReport($data));
                        }
                        break;
                case 'eventreport': 
                   if(count($request)>1){
                       echo json_encode($get->get_eventreport($request[1]));
                         }
                      else{
                        echo json_encode($get->get_eventreport($data));
                          }
                       break;
                case 'eventreportall': 
                 if(count($request)>1){
                 echo json_encode($get->get_eventreportAll($request[1]));
                   }
                     else{
                   echo json_encode($get->get_eventreportAll($data));
                          }
                     break;

                case 'annualreportall': 
                        if(count($request)>1){
                        echo json_encode($get->get_annualReportAll($request[1]));
                          }
                            else{
                          echo json_encode($get->get_annualReportAll($data));
                                 }
                            break;
                 case 'financialreportall': 
                      if(count($request)>1){
                     echo json_encode($get->get_financialreportAll($request[1]));
                         }
                         else{
                        echo json_encode($get->get_financialreportAll($data));
                             }
                    break;
                case 'financialreport':
                        if(count($request)>1){
                       echo json_encode($get->get_financialreport($request[1]));
                           }
                           else{
                          echo json_encode($get->get_financialreport($data));
                               }
                      break;
                 case 'annualreportonly': 
                     if(count($request)>1){
                     echo json_encode($get->get_annualonly($request[1]));
                        }
                         else{
                         echo json_encode($get->get_annualonly($data));
                           }
                           break;

                case 'eventreportonly': 
                  if(count($request)>1){
                     echo json_encode($get->get_eventonly($request[1]));
                          }
                      else{
                         echo json_encode($get->get_eventonly($data));
                         }
                        break;
                case 'financialreportonly': 
                     if(count($request)>1){
                     echo json_encode($get->get_financialonly($request[1]));
                       }
                     else{
                      echo json_encode($get->get_financialonly($data));
                         }
                       break;

                       case 'projectreport': 
                        if(count($request)>1){
                            echo json_encode($get->get_projectreport($request[1]));
                                }
                           else{
                            echo json_encode($get->get_projectreport($data));
                                   }
                            break;
    
                    case 'projectreportall': 
                        if(count($request)>1){
                            echo json_encode($get->get_projectreportAll($request[1]));
                                }
                            else{
                            echo json_encode($get->get_projectreportAll($data));
                             }
                            break;


                    case 'projectreportonly': 
                        if(count($request)>1){
                            echo json_encode($get->get_projectonly($request[1]));
                                }
                            else{
                            echo json_encode($get->get_projectonly($data));
                                }
                            break;
                            
                     case 'documentonly':  //bago
                        if(count($request)>1){
                            echo json_encode($get->get_documentisa($request[1]));
                                }
                            else{
                            echo json_encode($get->get_documentisa($data));
                                }
                            break;
                            
                    case 'documentall':  //bago lahat working
                        if(count($request)>1){
                            echo json_encode($get->get_documentall($request[1]));
                                }
                            else{
                            echo json_encode($get->get_documentall($data));
                                }
                            break;
                            
                    case 'documentone': //bago isa lang working
                        if(count($request)>1){
                            echo json_encode($get->get_documentonly($request[1]));
                                }
                            else{
                            echo json_encode($get->get_documentonly($data));
                                }
                            break;
                    case 'fetchelements':  //bago working
                    if(count($request)>1){
                          echo json_encode($get->fetchElementsByUserId($request[1]));
                                }
                            else{
                         echo json_encode($get->fetchElementsByUserId($data));
                              }
                            break;
                    case 'getusername':   //bago working
                                if(count($request)>1){
                                   echo json_encode($get->get_username($request[1]));
                                          }
                                   else{
                                   echo json_encode($get->get_username($data));
                                     }
                                   break;
                    case 'getallusernames': //bago working
                            if(count($request)>1){
                                echo json_encode($get->geteveryusers($request[1]));
                                       }
                                else{
                                echo json_encode($get->geteveryusers($data));
                                  } 
                                  break; 
                    case 'fetchall_collab': //bago working
                                    if(count($request)>1){
                                        echo json_encode($get->getcollaball($request[1]));
                                               }
                                        else{
                                        echo json_encode($get->getcollaball($data));
                                          } 
                                          break; 
                    case 'fetch_onecollab': //bago working
                                            if(count($request)>1){
                                                echo json_encode($get->getcollabone($request[1]));
                                                       }
                                                else{
                                                echo json_encode($get->getcollabone($data));
                                                  } 
                                                  break; 
                   case 'fetch_collabusernames': //bago working
                                           if(count($request)>1){
                                         echo json_encode($get->getCollUsernames($request[1]));
                                                               }
                                                        else{
                                                        echo json_encode($get->getCollUsernames($data));
                                                          } 
                                                          break; 
                    case 'fetch_templates': 
                                         if(count($request)>1){
                                            echo json_encode($get->gettemplatesall($request[1]));
                                                             }
                                                    else{
                                                        echo json_encode($get->gettemplatesall($data));
                                                                 } 
                                                             break; 
                    case 'fetch_onetemplate': 
                                         if(count($request)>1){
                                            echo json_encode($get->getTemplateById($request[1]));
                                                             }
                                                    else{
                                                        echo json_encode($get->getTemplateById($data));
                                                                 } 
                                                             break;
                                                             
                    case 'templateone':
                          if(count($request)>1){
                        echo json_encode($get->get_templateonly($request[1]));
                                     }
                            else{
                            echo json_encode($get->get_templateonly($data));
                                }
                              break;
                                
                                
                                case 'kuhafolders': 
                                    if(count($request)>1){
                                        echo json_encode($get->fetch_folders($request[1]));
                                    }
                                                                        else{
                                                                    echo json_encode($get->fetch_folders($data));
                                                                        }
                                                                    break;
                                                                    
                                                                    case 'unfilteredDocuments': 
                                            if(count($request)>1){
                                                echo json_encode($get->unfolderedRichtext($request[1]));
                                                    }
                                                else{
                                                echo json_encode($get->unfolderedRichtext($data));
                                                    }
                                                break;

                                                case 'filterDocumentbyFolderId': 
                                                    if(count($request)>1){
                                                        echo json_encode($get->getReportsByFolderId($request[1]));
                                                            }
                                                        else{
                                                        echo json_encode($get->getReportsByFolderId($data));
                                                            }
                                                        break;
    
                            
                                
            

            case 'logout':
                echo json_encode($get->logout($data));
                break;
                    
            default:
                http_response_code(403);
                echo json_encode(["error" => "Forbidden"]);
                break;
        }
        break;
    case 'POST':
        $data = json_decode(file_get_contents("php://input"));
        
        switch($request[0]){

            case 'signup':
                echo json_encode($post->signup($data));
                break;

            case 'login':
                echo json_encode($post->login($data));
                break;

            case 'report':
                echo json_encode($post->insertReport($data));
                break;
            case 'flipbook':
                echo json_encode($post->flipbook($data, $request[1]));
                 break;
                 case 'collage':
                    echo json_encode($post->uploadImage('file', $request[1]));
                    break;
             case 'annualreport':
                echo json_encode($post->annualreports($data, $request[1]));
                break; 
            case 'eventreport':
                 echo json_encode($post->eventreport($data, $request[1]));
                 break;
            case 'eventreportplus':
                echo json_encode($post->expenses($data, $request[1]));
                break;
            case 'financialreport':
                echo json_encode($post->insertFinancialReport($data, $request[1]));
                break;
            case 'projectreport';
                echo json_encode($post->projectreport($data, $request[1]));
                break; 
            case 'edit_projectreport';
                echo json_encode($post->edit_projectreport($data, $request[1]));
                break;   
            case 'edit_eventreport':
                echo json_encode($post->edit_eventreport($data, $request[1]));
                 break;
            case 'edit_financialreport':
                 echo json_encode($post->edit_financialreport($data, $request[1]));
                break;
            case 'edit_annualreport':
                 echo json_encode($post->edit_annualreport($data, $request[1]));
                break;
            case 'delete_annualreport':
               echo json_encode($post->delete_annualreport($request[1]));
                    break;
            case 'delete_financialreport':
                 echo json_encode($post->delete_financialreport($request[1]));
                break;
            case 'delete_eventreport':
                echo json_encode($post->delete_eventreport($request[1]));
                break;
            case 'delete_projectreport':
                echo json_encode($post->delete_projectreport($request[1]));
                break;
                
                            case 'new_emptydocument': //bago working
                echo json_encode($post->wordcreate($data, $request[1]));
                break;
                case 'edit_document': //bago working
                    echo json_encode($post->update_document($data, $request[1]));
                    break;
                    case 'sharelink': //bago working
                        echo json_encode($post->generateShareLink($data, $request[1]));
                        break;
                  case 'uploadelements': //bago working
                          echo json_encode($post->uploadElement('file', $request[1]));
                    break;
                case 'collabusers': 
                           echo json_encode($post->addSelectedUsers($data, $request[1]));
                            break;
                case 'delete_usercollab':
                                    echo json_encode($post->delete_coluser($request[1]));
                                    break;
                case 'add_title';
                                    echo json_encode($post->edit_title($data, $request[1]));
                                    break;  
                case 'delete_document':
                                    echo json_encode($post->delete_document($request[1]));
                                    break;
                                    
                //bago
                case 'template_title';
                                    echo json_encode($post->template_title($data, $request[1]));
                                    break;  
                                    
                case 'template_use';
                                    echo json_encode($post->templateuse($data, $request[1]));
                                    break;  
                                    
                                    
                                    
                                      case 'add_folder'; 
                                    echo json_encode($post->create_folder($data, $request[1]));
                                    break;  

                                    case 'delete_folder':
                                        if (count($request) > 1) {
                                            echo json_encode($post->deleteFolder($request[1]));
                                        } else {
                                            echo json_encode(['error' => 'Folder ID is required']);
                                        }
                                        break;

                                    case 'assignDocumentToFolder'; 
                                        echo json_encode($post->assignReportToFolder($data, $request[1]));
                                        break; 
                                        
                                 case 'removeFromFolder';  //bago
                                    echo json_encode($post->removefromfolder($request[1]));
                                    break; 

                        
                        
                                case 'edit_profile':
         echo json_encode($post->edit_profile($data, $request[1]));     //new
                    break;
                    case 'validate_password':
                        echo json_encode($post->validate_password($data, $request[1]));     //new
                                   break;

            default:
                http_response_code(403);
                echo json_encode(["error" => "Forbidden"]);
                break;
        }
        break;
    case 'PUT':
        $data = json_decode(file_get_contents("php://input"));
        switch($request[0]){
            case 'edit_report' :
                echo json_encode($put->edit_reports($data, $request[1]));
                break;
            case 'edit_username' :
                echo json_encode($put->update_username($data));
                break;
            case 'edit_email' :
                  echo json_encode($put->update_email($data, $request[1]));
                break;
            case 'edit_password' :
                echo json_encode($put->update_password($data, $request[1]));
                 break;
                

                default:
                http_response_code(403);
                echo json_encode(["error" => "Forbidden"]);
                break;
        } 
        break;
    case 'DELETE':
        switch($request[0]){
            case 'delete_report' :
                echo json_encode($delete->delete_reports($request[1]));
                break;

            default:
            http_response_code(403);
            echo json_encode(["error" => "Forbidden"]);

        } break;
            http_response_code(405);
            echo json_encode(["error" => "Method Not Allowed"]);
            break;
}

?>
