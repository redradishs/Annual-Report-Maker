import{a}from"./chunk-DP6XK2WQ.js";import"./chunk-CWTPBX7D.js";export default a();
