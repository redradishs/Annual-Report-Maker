<?php

require_once "global.php";


class Get extends GlobalMethods
{

    private $pdo;

    public function __construct(\PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    public function get_records($table, $condition = null)
    {
        $sqlString = "SELECT * FROM $table";
        if ($condition != null) {
            $sqlString = "WHERE" . $condition;
        }
        $result = $this->executeQuery($sqlString);

        if ($result['code'] == 200) {
            return $this->sendPayload($result['data'], 'success', 'Sucessfully retrieved records', $result['code']);
        }
        return $this->sendPayload(null, 'failed', 'Failed retrieved records', $result['code']);
    }

    public function executeQuery($sql)
    {
        $data = array();
        $errmsg = "";
        $code = 0;

        try {
            if ($result = $this->pdo->query($sql)->fetchAll()) {
                foreach ($result as $record) {
                    array_push($data, $record);
                }
                $code = 200;
                $result = null;
                return array("code" => $code, "data" => $data);
            } else {
                $errmsg = "No Data Found";
                $code = 404;
            }
        } catch (\PDOException $e) {
            $errmsg = $e->getMessage();
            $code = 403;
        }

        return array("code" => $code, "errmsg" => $errmsg);
    }



    public function get_eventexpenses($user_id)
    {

        $sqlString = "SELECT * FROM eventexpenses WHERE user_id = ? ORDER BY expense_id DESC LIMIT 1";
        $stmt = $this->pdo->prepare($sqlString);
        $stmt->bindParam(1, $user_id, PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            return $this->getResponse($result, "Success", null, 200);
        } else {
            return $this->getResponse(null, "Failed", "Failed to retrieve", 404);
        }
    }


    public function get_eventexpensessummary($event_id)
    {
        // Prepare the SQL query string
        $sqlString = "SELECT * FROM eventexpenses WHERE event_id = ? ORDER BY expense_id DESC LIMIT 1";

        // Prepare the statement
        $stmt = $this->pdo->prepare($sqlString);

        // Bind the parameter
        $stmt->bindParam(1, $event_id, PDO::PARAM_INT);

        // Execute the statement
        $stmt->execute();

        // Fetch the result
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        // Return the response based on the result
        if ($result) {
            return $this->getResponse($result, "Success", null, 200);
        } else {
            return $this->getResponse(null, "Failed", "Failed to retrieve", 404);
        }
    }



    public function get_signup($id = null)
    {
        $conditionString = null;
        if ($id != null) {
            $conditionString = "user_id=$id";
        }
        return $this->get_records("users", $conditionString);
    }

    public function get_flipbook($data)
    {
        $sqlString = "SELECT u.username, r.title, r.description, r.date_created, c.collage_desc, f.* 
        FROM users u
        JOIN reports r ON u.user_id = r.user_id 
        JOIN flipbook f ON r.report_id = f.report_id 
        JOIN collage c ON f.collage_id = c.collage_id 
        WHERE f.flipbook_id = :flipbook_id";


        $stmt = $this->pdo->prepare($sqlString);
        $stmt->bindParam(':flipbook_id', $data);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($result) {
            return $this->getResponse($result, "success", null, 200);
        } else {
            return $this->getResponse(null, "failed", "Failed retrieved records", 404);
        }
    }

    public function get_flipbookall()
    {
        $sqlString = "SELECT u.username, r.title, r.description, c.collage_desc, f.* 
            FROM users u
            JOIN reports r ON u.user_id = r.user_id 
            JOIN flipbook f ON r.report_id = f.report_id 
            JOIN collage c ON f.collage_id = c.collage_id";


        $stmt = $this->pdo->prepare($sqlString);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($result) {
            return $this->getResponse($result, "success", null, 200);
        } else {
            return $this->getResponse(null, "failed", "Failed retrieved records", 404);
        }
    }

    public function get_collage($userId)
    {
        $sqlString = "
            SELECT collage.*, eventreports.*
            FROM collage
            INNER JOIN eventreports ON collage.event_id = eventreports.event_id
            WHERE collage.user_id = ?
            ORDER BY collage.collage_id DESC
            LIMIT 1;
        ";
        $stmt = $this->pdo->prepare($sqlString);
        $stmt->execute([$userId]);

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            return $this->getResponse($result, "Success", null, 200);
        } else {
            return $this->getResponse(null, "Failed", "Failed to retrieve the collage", 404);
        }
    }

    public function getCollageAll($userId)
    {
        $sqlString = "
            SELECT collage.*, eventreports.*
            FROM collage
            INNER JOIN eventreports ON collage.event_id = eventreports.event_id
            WHERE collage.user_id = ?
            ORDER BY collage.collage_id;
        ";
        $stmt = $this->pdo->prepare($sqlString);
        $stmt->execute([$userId]);

        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($results) {
            return $this->getResponse($results, "Success", "Success", 200);
        } else {
            return $this->getResponse(null, "Failed", "Failed to retrieve the collages", 404);
        }
    }

    public function get_reports($data)
    {
        $sqlString = "SELECT * FROM reports WHERE report_id = ?";
        $stmt = $this->pdo->prepare($sqlString);
        $stmt->bindParam(1, $data);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (!empty($result)) {
            return $this->getResponse($result, "Success", null, 200);
        } else {
            return $this->getResponse(null, "Failed", "Failed to retrieve", 404);
        }
    }
    //Final
    public function get_profile($data)
    {
        // Select the most recent report by user_id
        $sqlString = "SELECT * FROM users WHERE user_id = ?";
        $stmt = $this->pdo->prepare($sqlString);
        $stmt->bindParam(1, $data, PDO::PARAM_INT); // Bind user_id as an integer
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC); // Fetch a single record with fetch()

        if ($result) { // Check if a record is returned
            return $this->getResponse($result, "Success", null, 200); // Success response
        } else {
            return $this->getResponse(null, "Failed", "Failed to retrieve", 404); // Failure response
        }
    }
    public function get_annualReport($data)
    {
        $sqlString = "SELECT * FROM annualreports WHERE user_id = ? ORDER BY created_at DESC LIMIT 1";
        $stmt = $this->pdo->prepare($sqlString);
        $stmt->bindParam(1, $data, PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            return $this->getResponse($result, "Success", null, 200);
        } else {
            return $this->getResponse(null, "Failed", "Failed to retrieve", 404);
        }
    }



    public function get_eventreport($data)
    {
        $sqlString = "SELECT * FROM eventreports WHERE user_id = ? ORDER BY created_at DESC LIMIT 1";
        $stmt = $this->pdo->prepare($sqlString);
        $stmt->bindParam(1, $data, PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            return $this->getResponse($result, "Success", null, 200);
        } else {
            return $this->getResponse(null, "Failed", "Failed to retrieve", 404);
        }
    }

    public function get_eventreportAll($data)
    {
        $sqlString = "SELECT * FROM eventreports WHERE user_id = ?";
        $stmt = $this->pdo->prepare($sqlString);
        $stmt->bindParam(1, $data, PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($result) {
            return $this->getResponse($result, "Success", null, 200);
        } else {
            return $this->getResponse(null, "Failed", "Failed to retrieve", 404);
        }
    }



    public function get_annualReportAll($data)
    {
        $sqlString = "SELECT * FROM annualreports WHERE user_id = ?";
        $stmt = $this->pdo->prepare($sqlString);
        $stmt->bindParam(1, $data, PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($result) {
            return $this->getResponse($result, "Success", null, 200);
        } else {
            return $this->getResponse(null, "Failed", "Failed to retrieve", 404);
        }
    }


    public function get_financialreportAll($data)
    {
        $sqlString = "SELECT * FROM financialreports WHERE user_id = ?";
        $stmt = $this->pdo->prepare($sqlString);
        $stmt->bindParam(1, $data, PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($result) {
            return $this->getResponse($result, "Success", null, 200);
        } else {
            return $this->getResponse(null, "Failed", "Failed to retrieve", 404);
        }
    }



    public function get_financialreport($data)
    {
        $sqlString = "SELECT * FROM financialreports WHERE user_id = ? ORDER BY date_created DESC LIMIT 1";
        $stmt = $this->pdo->prepare($sqlString);
        $stmt->bindParam(1, $data, PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            return $this->getResponse($result, "Success", null, 200);
        } else {
            return $this->getResponse(null, "Failed", "Failed to retrieve", 404);
        }
    }



    public function get_annualonly($data)
    {
        $sqlString = "SELECT * FROM annualreports WHERE report_id = ?";
        $stmt = $this->pdo->prepare($sqlString);
        $stmt->bindParam(1, $data, PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            return $this->getResponse($result, "Success", null, 200);
        } else {
            return $this->getResponse(null, "Failed", "Failed to retrieve", 404);
        }
    }



    public function get_eventonly($data)
    {
        $sqlString = "SELECT * FROM eventreports WHERE event_id = ?";
        $stmt = $this->pdo->prepare($sqlString);
        $stmt->bindParam(1, $data, PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            return $this->getResponse($result, "Success", null, 200);
        } else {
            return $this->getResponse(null, "Failed", "Failed to retrieve", 404);
        }
    }


    public function get_financialonly($data)
    {
        $sqlString = "SELECT * FROM financialreports WHERE financialreport_id = ?";
        $stmt = $this->pdo->prepare($sqlString);
        $stmt->bindParam(1, $data, PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            return $this->getResponse($result, "Success", null, 200);
        } else {
            return $this->getResponse(null, "Failed", "Failed to retrieve", 404);
        }
    }


    public function get_projectreport($data)
    {

        $sqlString = "SELECT * FROM projectreport WHERE user_id = ? ORDER BY created_at DESC LIMIT 1";
        $stmt = $this->pdo->prepare($sqlString);
        $stmt->bindParam(1, $data, PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            return $this->getResponse($result, "Success", null, 200);
        } else {
            return $this->getResponse(null, "Failed", "Failed to retrieve", 404);
        }
    }


    public function get_projectreportAll($data)
    {

        $sqlString = "SELECT * FROM projectreport WHERE user_id = ?";
        $stmt = $this->pdo->prepare($sqlString);
        $stmt->bindParam(1, $data, PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($result) {
            return $this->getResponse($result, "Success", null, 200);
        } else {
            return $this->getResponse(null, "Failed", "Failed to retrieve", 404);
        }
    }

    public function get_projectonly($data)
    {
        try {
            $sqlString = "SELECT * FROM projectreport WHERE projectID = ?";
            $stmt = $this->pdo->prepare($sqlString);

            if (!$stmt) {
                return $this->getResponse(null, "Failed", "Failed to prepare statement", 500);
            }

            $stmt->bindParam(1, $data, PDO::PARAM_INT);

            if (!$stmt->execute()) {
                return $this->getResponse(null, "Failed", "Failed to execute statement", 500);
            }

            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($result) {
                return $this->getResponse($result, "Success", null, 200);
            } else {
                return $this->getResponse(null, "Failed", "No record found", 404);
            }
        } catch (Exception $e) {
            return $this->getResponse(null, "Failed", "Exception: " . $e->getMessage(), 500);
        }
    }


    public function get_reportsall()
    {
        $sqlString = "SELECT * FROM reports";
        $stmt = $this->pdo->prepare($sqlString);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (!empty($result)) {
            return $this->getResponse($result, "Success", null, 200);
        } else {
            return $this->getResponse(null, "Failed", "Failed to retrieve", 404);
        }
    }


    public function get_documentonly($data)
    {
        try {
            $sqlString = "SELECT * FROM richtext WHERE id = ?";
            $stmt = $this->pdo->prepare($sqlString);

            if (!$stmt) {
                return $this->getResponse(null, "Failed", "Failed to prepare statement", 500);
            }

            $stmt->bindParam(1, $data, PDO::PARAM_INT);

            if (!$stmt->execute()) {
                return $this->getResponse(null, "Failed", "Failed to execute statement", 500);
            }

            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($result) {
                return $this->getResponse($result, "Success", null, 200);
            } else {
                return $this->getResponse(null, "Failed", "No record found", 404);
            }
        } catch (Exception $e) {
            return $this->getResponse(null, "Failed", "Exception: " . $e->getMessage(), 500);
        }
    }
    public function get_documentall($data)
    {
        try {
            $sqlString = "SELECT * FROM richtext WHERE user_id = ?";
            $stmt = $this->pdo->prepare($sqlString);

            if (!$stmt) {
                return $this->getResponse(null, "Failed", "Failed to prepare statement", 500);
            }

            $stmt->bindParam(1, $data, PDO::PARAM_INT);

            if (!$stmt->execute()) {
                return $this->getResponse(null, "Failed", "Failed to execute statement", 500);
            }

            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if ($result) {
                return $this->getResponse($result, "Success", null, 200);
            } else {
                return $this->getResponse(null, "Failed", "No records found", 404);
            }
        } catch (Exception $e) {
            return $this->getResponse(null, "Failed", "Exception: " . $e->getMessage(), 500);
        }
    }

    public function get_documentisa($data)
    {
        try {
            $sqlString = "SELECT * FROM richtext WHERE user_id = ? ORDER BY created_at DESC LIMIT 1";
            $stmt = $this->pdo->prepare($sqlString);

            if (!$stmt) {
                return $this->getResponse(null, "Failed", "Failed to prepare statement", 500);
            }

            $stmt->bindParam(1, $data, PDO::PARAM_INT);

            if (!$stmt->execute()) {
                return $this->getResponse(null, "Failed", "Failed to execute statement", 500);
            }

            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($result) {
                return $this->getResponse($result, "Success", null, 200);
            } else {
                return $this->getResponse(null, "Failed", "No record found", 404);
            }
        } catch (Exception $e) {
            return $this->getResponse(null, "Failed", "Exception: " . $e->getMessage(), 500);
        }
    }


    public function fetchElementsByUserId($userId)
    {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM elements WHERE user_id = ?");
            $stmt->execute([$userId]);
            $elements = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if (empty($elements)) {
                return $this->sendResponse("No elements found for the given user ID.", null, 404);
            }

            return $this->sendResponse("Elements fetched successfully.", $elements, 200);
        } catch (\PDOException $e) {
            return $this->sendResponse("Failed to fetch elements. Please try again later.", $e->getMessage(), 500);
        }
    }


    public function get_username($id)
    {
        $sql = "SELECT username FROM users WHERE user_id = ?";

        try {
            $statement = $this->pdo->prepare($sql);
            $statement->execute([$id]);
            $result = $statement->fetch(PDO::FETCH_ASSOC);
            return $result ? $result['username'] : null;
        } catch (\PDOException $e) {
            $errmsg = $e->getMessage();
            return null;
        }
    }

    // public function geteveryusers($excludeUserId) {
    //         $sql = "SELECT username FROM users WHERE user_id <> ?";

    //         try {
    //             $statement = $this->pdo->prepare($sql);
    //             $statement->execute([$excludeUserId]);
    //             $result = $statement->fetchAll(PDO::FETCH_ASSOC);
    //             return $result ? array_column($result, 'username') : [];
    //         } catch (\PDOException $e) {
    //             $errmsg = $e->getMessage();
    //             return [];
    //         }
    //     }


    public function geteveryusers($excludeUserId)
    {
        $sql = "SELECT user_id, username FROM users WHERE user_id <> ?";

        try {
            $statement = $this->pdo->prepare($sql);

            $statement->execute([$excludeUserId]);

            $result = $statement->fetchAll(PDO::FETCH_ASSOC);
            return $result ? $result : [];
        } catch (\PDOException $e) {
            $errmsg = $e->getMessage();
            error_log($errmsg);


            return [];
        }
    }


    public function getcollaball($userId)
    {
        $sql = "SELECT cd.*, rt.title 
            FROM collaboration_documents cd
            JOIN richtext rt ON cd.document_id = rt.id
            WHERE cd.user_id = :user_id";

        try {
            $statement = $this->pdo->prepare($sql);
            $statement->execute([':user_id' => $userId]);
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);

            return $result ? $result : [];
        } catch (\PDOException $e) {
            $errmsg = $e->getMessage();
            error_log($errmsg);
            return ['error' => 'Failed to fetch documents: ' . $errmsg];
        }
    }


    public function getTemplatesAll()
    {
        $sql = "SELECT * FROM templates";

        try {
            $statement = $this->pdo->prepare($sql);
            $statement->execute();
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);

            return $result ? $result : [];
        } catch (\PDOException $e) {
            $errmsg = $e->getMessage();
            error_log($errmsg);

            return ['error' => 'Failed to fetch documents: ' . $errmsg];
        }
    }


    public function getTemplateById($id)
    {
        $sql = "SELECT * FROM templates WHERE id = :id";

        try {
            $statement = $this->pdo->prepare($sql);
            $statement->execute([':id' => $id]);
            $result = $statement->fetch(PDO::FETCH_ASSOC);

            return $result ? $result : [];
        } catch (\PDOException $e) {
            $errmsg = $e->getMessage();
            error_log($errmsg);
            return ['error' => 'Failed to fetch template: ' . $errmsg];
        }
    }


    public function getcollabone($postId)
    {
        $sql = "SELECT cd.collab_id, cd.document_id, cd.user_id, rt.content 
            FROM collaboration_documents cd
            JOIN richtext rt ON cd.document_id = rt.id
            WHERE cd.document_id = :document_id";

        try {

            $statement = $this->pdo->prepare($sql);


            $statement->execute([':document_id' => $postId]);


            $result = $statement->fetch(PDO::FETCH_ASSOC);


            return $result ? $result : [];
        } catch (\PDOException $e) {

            $errmsg = $e->getMessage();
            error_log($errmsg);

            return ['error' => 'Failed to fetch document: ' . $errmsg];
        }
    }

    public function getCollUsernames($postId)
    {
        $sql = "
        SELECT u.username, collab_id  
        FROM collaboration_documents cd
        JOIN users u ON cd.user_id = u.user_id
        WHERE cd.document_id = :document_id";

        try {

            $statement = $this->pdo->prepare($sql);


            $statement->execute([':document_id' => $postId]);


            $results = $statement->fetchAll(PDO::FETCH_ASSOC);


            return $results ? $results : [];
        } catch (\PDOException $e) {

            $errmsg = $e->getMessage();
            error_log($errmsg);

            return ['error' => 'Failed to fetch usernames: ' . $errmsg];
        }
    }


    //bago working

    public function get_templateonly($data)
    {
        try {
            $sqlString = "SELECT * FROM templates WHERE id = ?";
            $stmt = $this->pdo->prepare($sqlString);

            if (!$stmt) {
                return $this->getResponse(null, "Failed", "Failed to prepare statement", 500);
            }

            $stmt->bindParam(1, $data, PDO::PARAM_INT);

            if (!$stmt->execute()) {
                return $this->getResponse(null, "Failed", "Failed to execute statement", 500);
            }

            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($result) {
                return $this->getResponse($result, "Success", null, 200);
            } else {
                return $this->getResponse(null, "Failed", "No record found", 404);
            }
        } catch (Exception $e) {
            return $this->getResponse(null, "Failed", "Exception: " . $e->getMessage(), 500);
        }
    }

    //bago working
    public function get_templateisa($data)
    {
        try {
            $sqlString = "SELECT * FROM templates WHERE user_id = ? ORDER BY created_at DESC LIMIT 1";
            $stmt = $this->pdo->prepare($sqlString);

            if (!$stmt) {
                return $this->getResponse(null, "Failed", "Failed to prepare statement", 500);
            }

            $stmt->bindParam(1, $data, PDO::PARAM_INT);

            if (!$stmt->execute()) {
                return $this->getResponse(null, "Failed", "Failed to execute statement", 500);
            }

            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($result) {
                return $this->getResponse($result, "Success", null, 200);
            } else {
                return $this->getResponse(null, "Failed", "No record found", 404);
            }
        } catch (Exception $e) {
            return $this->getResponse(null, "Failed", "Exception: " . $e->getMessage(), 500);
        }
    }


    public function fetch_folders($user_id)
    {
        $sql = "SELECT * FROM user_folders WHERE user_id = :user_id";

        try {
            $statement = $this->pdo->prepare($sql);
            $statement->execute([':user_id' => $user_id]);
            $folders = $statement->fetchAll(PDO::FETCH_ASSOC);

            return ['success' => true, 'folders' => $folders];
        } catch (\PDOException $e) {
            $errmsg = $e->getMessage();
            error_log($errmsg);
            return ['error' => 'Failed to fetch folders: ' . $errmsg];
        }
    }

    public function unfolderedRichtext($userId)
    {
        $sql = "SELECT * FROM richtext WHERE user_id = :user_id AND folder_id = 0";

        try {
            $statement = $this->pdo->prepare($sql);
            $statement->execute([':user_id' => $userId]);
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);

            return $result ? $result : [];
        } catch (\PDOException $e) {
            $errmsg = $e->getMessage();
            error_log($errmsg);
            return ['error' => 'Failed to fetch unfoldered richtext: ' . $errmsg];
        }
    }


    public function getReportsByFolderId($folderId)
    {
        $sql = "SELECT * FROM richtext WHERE folder_id = :folder_id";

        try {
            $statement = $this->pdo->prepare($sql);
            $statement->execute([':folder_id' => $folderId]);
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);

            return $result ? $result : [];
        } catch (\PDOException $e) {
            $errmsg = $e->getMessage();
            error_log($errmsg);
            return ['error' => 'Failed to fetch reports: ' . $errmsg];
        }
    }


    //bagong bago

    public function fetch_shared_content($link_token)
    {
        $sqlString = "SELECT post_id, can_edit, view_limit, destroy_after_view, views, created_at 
                  FROM shareable_links WHERE link_token = ?";
        $stmt = $this->pdo->prepare($sqlString);
        $stmt->bindParam(1, $link_token, PDO::PARAM_STR);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            if ($row['views'] >= $row['view_limit']) {
                return $this->getResponse(null, "Failed", "The document has been destroyed", 200);
            }

            $post_id = $row['post_id'];
            $can_edit = $row['can_edit'];
            $view_limit = $row['view_limit'];
            $views = $row['views'];
            $created_at = $row['created_at'];
            $destroy_after_view = $row['destroy_after_view'];

            // Fetch content
            $sql = "SELECT id, user_id, content, title FROM richtext WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(1, $post_id, PDO::PARAM_INT);
            $stmt->execute();
            $content_row = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($content_row) {
                $content = $content_row['content'];
                $title = $content_row['title'];
                $id = $content_row['id'];
                $user_id = $content_row['user_id'];

                // Update views
                $sql = "UPDATE shareable_links SET views = views + 1 WHERE link_token = ?";
                $stmt = $this->pdo->prepare($sql);
                $stmt->bindParam(1, $link_token, PDO::PARAM_STR);
                $stmt->execute();

                if ($destroy_after_view && $row['views'] + 1 >= $row['view_limit']) {
                    // Delete the link if it should be destroyed after view
                    $sql = "DELETE FROM shareable_links WHERE link_token = ?";
                    $stmt = $this->pdo->prepare($sql);
                    $stmt->bindParam(1, $link_token, PDO::PARAM_STR);
                    $stmt->execute();
                }

                return $this->getResponse([
                    'content' => $content,
                    'title' => $title,  // Include the title in the response
                    'id' => $id,
                    'user_id' => $user_id,
                    'can_edit' => $can_edit,
                    'view_limit' => $view_limit,
                    'views' => $views,
                    'created_at' => $created_at,
                    'destroy_after_view' => $destroy_after_view
                ], "Success", null, 200);
            } else {
                return $this->getResponse(null, "Failed", "Content not found", 404);
            }
        } else {
            return $this->getResponse(null, "Failed", "Invalid link", 404);
        }
    }







    public function isUserLoggedIn()
    {
        return isset($_SESSION['user_id']);
    }

    public function logout()
    {
        session_unset();
        session_destroy();
    }
}
